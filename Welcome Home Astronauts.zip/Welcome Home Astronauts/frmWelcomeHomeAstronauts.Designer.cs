﻿namespace Welcome_Home_Astronauts
{
    partial class frmWelcomeHomeAstronauts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmWelcomeHomeAstronauts));
            this.grpBoxAstronauts = new System.Windows.Forms.GroupBox();
            this.txtBoxPlanets = new System.Windows.Forms.TextBox();
            this.lblPlanets = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.lblDaysInSpace = new System.Windows.Forms.Label();
            this.btnDaysInSpace = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnJoke = new System.Windows.Forms.Button();
            this.txtBoxAge = new System.Windows.Forms.TextBox();
            this.txtBoxName = new System.Windows.Forms.TextBox();
            this.lblAge = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.btnPlanetNames = new System.Windows.Forms.Button();
            this.grpBoxAstronauts.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpBoxAstronauts
            // 
            this.grpBoxAstronauts.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.grpBoxAstronauts.Controls.Add(this.btnPlanetNames);
            this.grpBoxAstronauts.Controls.Add(this.txtBoxPlanets);
            this.grpBoxAstronauts.Controls.Add(this.lblPlanets);
            this.grpBoxAstronauts.Controls.Add(this.radioButton1);
            this.grpBoxAstronauts.Controls.Add(this.lblDaysInSpace);
            this.grpBoxAstronauts.Controls.Add(this.btnDaysInSpace);
            this.grpBoxAstronauts.Controls.Add(this.btnExit);
            this.grpBoxAstronauts.Controls.Add(this.btnClear);
            this.grpBoxAstronauts.Controls.Add(this.btnJoke);
            this.grpBoxAstronauts.Controls.Add(this.txtBoxAge);
            this.grpBoxAstronauts.Controls.Add(this.txtBoxName);
            this.grpBoxAstronauts.Controls.Add(this.lblAge);
            this.grpBoxAstronauts.Controls.Add(this.lblName);
            this.grpBoxAstronauts.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.grpBoxAstronauts.Location = new System.Drawing.Point(12, 21);
            this.grpBoxAstronauts.Name = "grpBoxAstronauts";
            this.grpBoxAstronauts.Size = new System.Drawing.Size(1185, 748);
            this.grpBoxAstronauts.TabIndex = 0;
            this.grpBoxAstronauts.TabStop = false;
            this.grpBoxAstronauts.Text = "Welcome Home Astronauts!";
            // 
            // txtBoxPlanets
            // 
            this.txtBoxPlanets.Location = new System.Drawing.Point(365, 402);
            this.txtBoxPlanets.Name = "txtBoxPlanets";
            this.txtBoxPlanets.Size = new System.Drawing.Size(100, 35);
            this.txtBoxPlanets.TabIndex = 13;
            this.txtBoxPlanets.TextChanged += new System.EventHandler(this.txtBoxPlanets_TextChanged);
            // 
            // lblPlanets
            // 
            this.lblPlanets.Location = new System.Drawing.Point(47, 373);
            this.lblPlanets.Name = "lblPlanets";
            this.lblPlanets.Size = new System.Drawing.Size(256, 78);
            this.lblPlanets.TabIndex = 12;
            this.lblPlanets.Text = "How many planets are in the solar system?";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(344, 296);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(287, 33);
            this.radioButton1.TabIndex = 11;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "You have a message!";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // lblDaysInSpace
            // 
            this.lblDaysInSpace.Location = new System.Drawing.Point(656, 239);
            this.lblDaysInSpace.Name = "lblDaysInSpace";
            this.lblDaysInSpace.Size = new System.Drawing.Size(494, 66);
            this.lblDaysInSpace.TabIndex = 10;
            this.lblDaysInSpace.Text = "Click below to see how many days the NASA Astronauts were in space for";
            // 
            // btnDaysInSpace
            // 
            this.btnDaysInSpace.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDaysInSpace.BackgroundImage")));
            this.btnDaysInSpace.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDaysInSpace.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnDaysInSpace.Location = new System.Drawing.Point(672, 349);
            this.btnDaysInSpace.Name = "btnDaysInSpace";
            this.btnDaysInSpace.Size = new System.Drawing.Size(265, 194);
            this.btnDaysInSpace.TabIndex = 9;
            this.btnDaysInSpace.UseVisualStyleBackColor = true;
            this.btnDaysInSpace.Click += new System.EventHandler(this.btnDaysInSpace_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(1074, 34);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(95, 37);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnClear.Location = new System.Drawing.Point(989, 459);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(161, 84);
            this.btnClear.TabIndex = 7;
            this.btnClear.Text = "Start Again";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnJoke
            // 
            this.btnJoke.BackColor = System.Drawing.Color.Violet;
            this.btnJoke.ForeColor = System.Drawing.Color.Blue;
            this.btnJoke.Location = new System.Drawing.Point(812, 42);
            this.btnJoke.Name = "btnJoke";
            this.btnJoke.Size = new System.Drawing.Size(186, 147);
            this.btnJoke.TabIndex = 4;
            this.btnJoke.Text = "Click here for a space joke";
            this.btnJoke.UseVisualStyleBackColor = false;
            this.btnJoke.Click += new System.EventHandler(this.btnJoke_Click);
            // 
            // txtBoxAge
            // 
            this.txtBoxAge.Location = new System.Drawing.Point(375, 179);
            this.txtBoxAge.Name = "txtBoxAge";
            this.txtBoxAge.Size = new System.Drawing.Size(166, 35);
            this.txtBoxAge.TabIndex = 3;
            this.txtBoxAge.TextChanged += new System.EventHandler(this.txtBoxAge_TextChanged);
            // 
            // txtBoxName
            // 
            this.txtBoxName.Location = new System.Drawing.Point(375, 101);
            this.txtBoxName.Name = "txtBoxName";
            this.txtBoxName.Size = new System.Drawing.Size(192, 35);
            this.txtBoxName.TabIndex = 2;
            this.txtBoxName.TextChanged += new System.EventHandler(this.txtBoxName_TextChanged);
            // 
            // lblAge
            // 
            this.lblAge.Location = new System.Drawing.Point(46, 161);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(257, 131);
            this.lblAge.TabIndex = 1;
            this.lblAge.Text = "How many times have you flown around the sun? (Your age?) ";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(46, 101);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(215, 29);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Enter Your name!";
            // 
            // btnPlanetNames
            // 
            this.btnPlanetNames.BackColor = System.Drawing.Color.Orchid;
            this.btnPlanetNames.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btnPlanetNames.Location = new System.Drawing.Point(116, 520);
            this.btnPlanetNames.Name = "btnPlanetNames";
            this.btnPlanetNames.Size = new System.Drawing.Size(219, 178);
            this.btnPlanetNames.TabIndex = 14;
            this.btnPlanetNames.Text = "Planet Names and Distance From The Sun";
            this.btnPlanetNames.UseVisualStyleBackColor = false;
            this.btnPlanetNames.Click += new System.EventHandler(this.btnPlanetNames_Click);
            // 
            // frmWelcomeHomeAstronauts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1333, 797);
            this.Controls.Add(this.grpBoxAstronauts);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "frmWelcomeHomeAstronauts";
            this.Text = "Welcome Home Astronauts";
            this.grpBoxAstronauts.ResumeLayout(false);
            this.grpBoxAstronauts.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpBoxAstronauts;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtBoxAge;
        private System.Windows.Forms.TextBox txtBoxName;
        private System.Windows.Forms.Button btnJoke;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnDaysInSpace;
        private System.Windows.Forms.Label lblDaysInSpace;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label lblPlanets;
        private System.Windows.Forms.TextBox txtBoxPlanets;
        private System.Windows.Forms.Button btnPlanetNames;
    }
}

