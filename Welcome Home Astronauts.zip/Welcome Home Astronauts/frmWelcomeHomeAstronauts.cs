﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Welcome_Home_Astronauts//This is the namespace for the form//
{
    public partial class frmWelcomeHomeAstronauts : Form
    //this is a public class for the form meaning the form can be accessed from other classes//
    {
        public frmWelcomeHomeAstronauts()
        {
            InitializeComponent();//This is the method that initializes the form//
        }

        int Age;//This is the variable for the age//

        private void btnExit_Click(object sender, EventArgs e)
        //This is the event handler for the exit button//
        {
            //This is the code that will close the form when the exit button is clicked//
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        // This is the event handler to clear the form//
        {
            txtBoxName.Clear();//clears the name text box//
            txtBoxAge.Clear();//clears the age text box//
            txtBoxName.Focus();//moves the cursor to the name text box//
        }

        private void btnJoke_Click(object sender, EventArgs e)
        //This is the event handler for the joke button//
        {
            //This is the joke that will be displayed when the joke button is clicked//
            MessageBox.Show("Q: What did the alien say to the cat? 👽🐈" + "      " + "A: Take me to your litter");
        }


        private void btnDaysInSpace_Click(object sender, EventArgs e)
        {
            int DaysInSpace;//This is the variable for the days in space//
            DaysInSpace = 286;//This is the number of days in space//

            for (int i = 285; i < 286; i++)
            //this for loop assigns the variable i the value of 285 and increments it by 1 until it reaches 286//
            {
                //This is the code that will display the number of days in space//
                MessageBox.Show("NASAs Astronauts were in space for" + " " + DaysInSpace + " " + "days. Upon Landing they were greeted by curious Dolphins! Our Astronauts are very brave!");
            }

        }

        private void txtBoxName_TextChanged(object sender, EventArgs e)
        //This is the event handler for the name text box//
        {
            //the Name variable is assigned the value of the text entered in the name text box//
            Name = txtBoxName.Text;

        }


        private void txtBoxAge_TextChanged(object sender, EventArgs e)
        {

            try
            {
                Age = Convert.ToInt32(txtBoxAge.Text);//specifies that the age is an integer//

            }
            catch
            {
                //This is the code that will display an error message if the user enters anything other than a whole number//
                MessageBox.Show("Please enter a whole number.");
            }

            



        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        //This is the event handler for the radio button//
        {
            //I created a string variable called greeting that will display a message with the user's name and age//
            string greeting = "Greetings Cadet" + " " + Name + " " + "You have taken" + " " + Age + " " + "trips around the sun. What a ride!";
            MessageBox.Show(greeting);//This is the message that will be displayed//


        }

        private void txtBoxPlanets_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int planets;//This is the variable for the planets//
                planets = Convert.ToInt32(txtBoxPlanets.Text);//this converts the users text to an int//

                //I created an if/else if/ else statement to display a message based on the number of planets the user enters//
                if (planets == 8)
                {
                    MessageBox.Show("You are correct! There are 8 planets in our solar system.");
                }
                else if (planets == 9)
                {
                    MessageBox.Show("Pluto was once considered the ninth planet, but in 2006, the International Astronomical Union (IAU) reclassified it as a dwarf planet.");
                }
                else if (planets > 9)
                {
                    MessageBox.Show("There are fewer planets in our solar system than that.");
                }
                else if (planets < 8)
                {
                    MessageBox.Show("There are more planets in our solar system than that.");
                }
                else
                {
                    MessageBox.Show("Please enter a whole number.");
                }
            }

            catch//this allows the user to delete the text in the text box without getting an error message//
            {
                txtBoxPlanets.Text = "";
            }
        



        }

        private void btnPlanetNames_Click(object sender, EventArgs e)
        {
            const int SIZE = 8;//This is the size of the Planets array//
            string[] Planets = new string[SIZE] {"Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"};//This is the array for the planets//

            const int iSIZE = 8;//This is the size of the i array//
            //This is the array for the distance of the planets from the sun//
            double[] distanceArray = new double[iSIZE] { 36000000, 67000000, 93000000, 142000000, 484000000, 890000000, 1800000000, 2800000000 };

            //I created a for loop to display the planets names and their distance from the sun//
            for (int index = 0; index < SIZE; index++)
                //the loop starts at index{0} and increments by 1 until it reaches the last index//
                MessageBox.Show("The planet" + " " + Planets[index] + " " + "is" + " " + "approximately" + " " + distanceArray[index] + " " + "miles from the sun.");




        }
    }
}
